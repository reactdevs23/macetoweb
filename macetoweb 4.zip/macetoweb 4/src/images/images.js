import logo from "./logo.png";
import heroImg from "./heroImg.png";

import playing from "./playing.png";
import feature1 from "./feature1.png";
import feature2 from "./feature2.png";
import feature3 from "./feature3.png";
import appStore from "./appStore.png";
import googlePlay from "./googlePlay.png";
import pattern from "./pattern.png";

export {
  logo,
  heroImg,
  playing,
  feature1,
  feature2,
  feature3,
  appStore,
  googlePlay,
  pattern,
};
