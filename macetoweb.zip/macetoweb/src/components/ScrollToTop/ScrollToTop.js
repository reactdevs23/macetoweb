import React from "react";

const ScrollToTop = () => {
  return <div>ScrollToTop</div>;
};

export default ScrollToTop;
