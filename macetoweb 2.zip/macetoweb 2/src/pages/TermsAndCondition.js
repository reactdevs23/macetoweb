import React from "react";
import TermsCondition from "../components/TermsAndCondition/TermsCondition";

const TermsAndCondition = () => {
  return (
    <>
      <TermsCondition />
    </>
  );
};

export default TermsAndCondition;
