import React from "react";
import PrivacyAndPolicy from "../components/PrivacyPolicy/PrivacyAndPolicy";

const PrivacyPolicy = () => {
  return (
    <>
      <PrivacyAndPolicy />
    </>
  );
};

export default PrivacyPolicy;
